import React from 'react'



export default function footer() {
    return (
        <div className="footer">
            <button><i className="fa-brands fa-twitter"></i></button>
            <button><i className="fa-brands fa-square-facebook"></i></button>
            <button><i className="fa-brands fa-instagram"></i></button>
            <button><i className="fa-brands fa-github"></i></button>
        </div>
        
    )
}