import React from 'react'

export default function interest() {
    return (
        <div className="interest">
            <h1>Interests</h1>
            <p>Food expert. Music scholar. Reader. Internet fanatic. Bacon buff. Entrepreneur. Travel geek. Pop culture ninja. Coffee fanatic.</p>
        </div>
    )
}
